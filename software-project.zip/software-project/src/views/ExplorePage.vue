<template>
  <div class="explore-page">
    <h1>探索</h1>
    <p>这里是探索页面，可以展示推荐文章、热门标签等内容。</p>
    <p>此功能正在建设中...</p>
  </div>
</template>

<script setup>
// No specific logic for now
</script>

<style scoped>
.explore-page {
  padding: 20px;
  text-align: center;
}
.explore-page h1 {
  margin-bottom: 20px;
}
</style>